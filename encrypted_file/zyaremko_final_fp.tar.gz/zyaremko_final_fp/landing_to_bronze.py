from pyspark.sql import SparkSession

def main():
    spark = SparkSession.builder \
        .appName("LandingToBronze") \
        .getOrCreate()

    # 🟢 URL на FTP
    athlete_bio_url = "https://ftp.goit.study/neoversity/athlete_bio.csv"
    athlete_event_url = "https://ftp.goit.study/neoversity/athlete_event_results.csv"

    # 🟢 Читаємо athlete_bio
    df_bio = spark.read.option("header", True).csv(athlete_bio_url)
    df_bio.show(5)
    df_bio.write.mode("overwrite").parquet("dags/zyaremko_final_fp/datalake/bronze/athlete_bio")
    print("✅ athlete_bio збережено у Bronze")

    # 🟢 Читаємо athlete_event_results
    df_event = spark.read.option("header", True).csv(athlete_event_url)
    df_event.show(5)
    df_event.write.mode("overwrite").parquet("dags/zyaremko_final_fp/datalake/bronze/athlete_event_results")
    print("✅ athlete_event_results збережено у Bronze")

    spark.stop()

if __name__ == "__main__":
    main()
