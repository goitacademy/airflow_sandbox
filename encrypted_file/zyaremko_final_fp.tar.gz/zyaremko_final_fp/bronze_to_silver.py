import re
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

# 🟢 Функція очищення тексту
def clean_text(text):
    if text is None:
        return None
    return re.sub(r'[^a-zA-Z0-9,.\\"\']', '', str(text))

clean_text_udf = udf(clean_text, StringType())

def process_table(spark, table_name):
    # Читання Bronze
    df = spark.read.parquet(f"dags/zyaremko_final_fp/datalake/bronze/{table_name}")

    # Очищення текстових колонок
    for col_name, dtype in df.dtypes:
        if dtype == "string":
            df = df.withColumn(col_name, clean_text_udf(df[col_name]))

    # Дедублікація
    df = df.dropDuplicates()

    # Вивід у лог
    df.show(5)

    # Запис у Silver
    output_path = f"dags/zyaremko_final_fp/datalake/silver/{table_name}"
    df.write.mode("overwrite").parquet(output_path)
    print(f"✅ {table_name} збережено у Silver")

def main():
    spark = SparkSession.builder \
        .appName("BronzeToSilver") \
        .getOrCreate()

    # 🟢 Обробляємо обидві таблиці
    process_table(spark, "athlete_bio")
    process_table(spark, "athlete_event_results")

    spark.stop()

if __name__ == "__main__":
    main()

