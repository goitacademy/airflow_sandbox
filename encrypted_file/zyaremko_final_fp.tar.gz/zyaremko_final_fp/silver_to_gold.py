from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, current_timestamp

def main():
    spark = SparkSession.builder \
        .appName("SilverToGold") \
        .getOrCreate()

    # 🟢 Читаємо Silver таблиці
    df_bio = spark.read.parquet("dags/zyaremko_final_fp/datalake/silver/athlete_bio")
    df_event = spark.read.parquet("dags/zyaremko_final_fp/datalake/silver/athlete_event_results")

    # 🟢 Join по athlete_id
    df_joined = df_event.join(df_bio, on="athlete_id", how="inner")

    # 🟢 Приведення колонок weight і height до числового типу
    df_joined = df_joined \
        .withColumn("weight", col("weight").cast("double")) \
        .withColumn("height", col("height").cast("double"))

    # 🟢 Агрегація
    df_result = df_joined.groupBy("sport", "medal", "sex", "country_noc") \
        .agg(
            avg("weight").alias("avg_weight"),
            avg("height").alias("avg_height")
        ) \
        .withColumn("timestamp", current_timestamp())

    # 🟢 Вивід у лог
    df_result.show(5)

    # 🟢 Запис у Gold
    output_path = "dags/zyaremko_final_fp/datalake/gold/avg_stats"
    df_result.write.mode("overwrite").parquet(output_path)
    print(f"✅ Gold результат збережено у {output_path}")

    spark.stop()

if __name__ == "__main__":
    main()

