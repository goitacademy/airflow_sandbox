from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from datetime import datetime

# 🟢 Аргументи DAG
default_args = {
    "owner": "airflow",
    "start_date": datetime(2024, 1, 1),
    "retries": 1,
}

with DAG(
    dag_id="fp_batch_datalake_zyaremko",
    default_args=default_args,
    schedule_interval=None,   # запускаємо вручну
    catchup=False,
    tags=["zyaremko", "final", "batch"]
) as dag:

    # 🟢 Крок 1: Landing → Bronze
    landing_to_bronze = SparkSubmitOperator(
        task_id="landing_to_bronze",
        application="zyaremko_final_fp/landing_to_bronze.py",
        conn_id="spark-default",
        verbose=True
    )

    # 🟢 Крок 2: Bronze → Silver
    bronze_to_silver = SparkSubmitOperator(
        task_id="bronze_to_silver",
        application="zyaremko_final_fp/bronze_to_silver.py",
        conn_id="spark-default",
        verbose=True
    )

    # 🟢 Крок 3: Silver → Gold
    silver_to_gold = SparkSubmitOperator(
        task_id="silver_to_gold",
        application="zyaremko_final_fp/silver_to_gold.py",
        conn_id="spark-default",
        verbose=True
    )

    # Встановлюємо залежності
    landing_to_bronze >> bronze_to_silver >> silver_to_gold

