from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from datetime import datetime

default_args = {
    'start_date': datetime(2023, 1, 1),
    'depends_on_past': False,
    'retries': 1,
}

with DAG(
    dag_id='Filonenko_batch_pipeline',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=['Filonenko'],
) as dag:

    landing_to_bronze = SparkSubmitOperator(
        task_id='landing_to_bronze',
        conn_id='spark-default',
        application='/opt/airflow/dags/Filonenko/landing_to_bronze.py',
        dag=dag
    )

    bronze_to_silver = SparkSubmitOperator(
        task_id='bronze_to_silver',
        conn_id='spark-default',
        application='/opt/airflow/dags/Filonenko/bronze_to_silver.py',
        dag=dag
    )

    silver_to_gold = SparkSubmitOperator(
        task_id='silver_to_gold',
        conn_id='spark-default',
        application='/opt/airflow/dags/Filonenko/silver_to_gold.py',
        dag=dag
    )

    landing_to_bronze >> bronze_to_silver >> silver_to_gold
